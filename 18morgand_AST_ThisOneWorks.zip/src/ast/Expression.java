package ast;
/**
 * Superclass for all Expressions
 * 
 * @author Morgan Douglas
 * @version 03/12/18
 */
public abstract class Expression 
{

    public int getValue() {
        return 0;
    }
    
}
