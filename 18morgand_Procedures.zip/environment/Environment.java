package environment;

import java.util.HashMap;
import java.util.Map;

import ast.ProcedureDeclaration;
import ast.Statement;
/**
 * Environment class keeps track variables, containing methods to get and set variable
 * values.
 * 
 * @author Morgan Douglas
 * @version Mar 19, 2018
 */
public class Environment 
{
    private Map<String, Integer> vars;  //maps variable names to values
    
    private Map<String, ProcedureDeclaration> procedures; //maps procedure names to
                                                          //procedures
    /**
     * Constructor for Environment objects
     */
    public Environment()
    {
        vars = new HashMap<String, Integer>();  //instantiates vars
        procedures = new HashMap<String, ProcedureDeclaration>(); //instantiates procedures
    }
    
    /**
     * Alternative constructor if vars and procedures are already known to an extent
     * 
     * @param vars
     * @param procedures
     */
    public Environment(Map<String, Integer> vars, Map<String, ProcedureDeclaration> procedures)
    {
        this.vars = new HashMap<String, Integer>();
        this.vars.putAll(vars);
        
        this.procedures = new HashMap<String, ProcedureDeclaration>();
        this.procedures.putAll(procedures);
    }
    
    /**
     * @param variable name of variable to which value is to be attached
     * @param value the value of variable
     * 
     * @postcondition variable and value have been put into vars, as key and value,
     *     respectively
     */
    public void setVariable(String variable, int value)
    {
        vars.put(variable, value);
    }
    
    /**
     * @param variable the name of the variable who's value is being retrieved
     * @return Integer value associated with variable name
     */
    public Integer getVariable(String variable)
    {
        return vars.get(variable);
    }
    
    /**
     * @param procedureName the name of the procedure
     * @param declaration the program that the name is to be mapped to
     * 
     * @postcondition procedureName and declaration have been put into procedures, as key and value,
     *     respectively
     */
    public void setProcedure(String procedureName, ProcedureDeclaration declaration)
    {
        procedures.put(procedureName, declaration);
    }
    
    public ProcedureDeclaration getProcedure(String procedureName)
    {
        return procedures.get(procedureName);
    }
    
    public Map<String, Integer> getAllVars()
    {
        return vars;
    }
    
    public Map<String, ProcedureDeclaration> getAllProcedures()
    {
        return procedures;
    }

}
