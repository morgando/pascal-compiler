package ast;

import java.util.ArrayList;

/**
 * ProcedureDeclaration stores the name and executable program associated 
 * with a Pascal procedure.
 *
 * @author Morgan Douglas
 * @version Apr 13, 2018
 */
public class ProcedureDeclaration extends Statement
{
    private String name;
    private Statement action;
    private ArrayList<String> vars;
    
    /**
     * Constructor for ProcedureDeclaration objects
     * 
     * @param name the name of the procedure
     * @param action the program that runs as a result of a call to the
     * procedure
     * FIX@param numVars the number of parameters required by the procedure
     */
    public ProcedureDeclaration(String name, Statement action, ArrayList<String> vars)
    {
        this.name = name;
        this.action = action;
        this.vars = vars;
    }
    
    /**
     * @return the name of the procedure
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * @return the program that runs as a result of a call to the procedure
     */
    public Statement getAction()
    {
        return action;
    }
    
    /**
     *FIX @return number of parameters required by procedure
     */
    public ArrayList<String> getParams()
    {
        return vars;
    }

}
