package ast;
/**
 * Superclass for all Expressions
 * 
 * @author Morgan Douglas
 * @version 03/12/18
 */
public abstract class Expression extends Parseable
{

    public int getValue() {
        return 0;
    }
    
}
