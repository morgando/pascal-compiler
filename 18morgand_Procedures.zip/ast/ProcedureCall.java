package ast;

import java.util.ArrayList;

/**
 * ProcedureCall stores the name and parameters passed in a call
 * to a Pascal procedure
 * 
 * @author Morgan Douglas
 * @version Apr 13, 2018
 */
public class ProcedureCall extends Expression
{
    private String name;
    private ArrayList<Expression> params;
    
    /**
     * Constructor for ProcedureCall objects. 
     * 
     * @param name the name of the procedure being called
     * @param params contains all the Expression objects being passed
     *     as parameters
     */
    public ProcedureCall(String name, ArrayList<Expression> params)
    {
        this.name = name;
        this.params = params;
    }
    
    /**
     * @return the name of the procedure being called
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * @return ArrayList containing all the Expression objects being passed
     *     as parameters
     */
    public ArrayList<Expression> getParams()
    {
        return params;
    }
}
