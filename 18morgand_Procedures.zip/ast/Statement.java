package ast;
/**
 * Superclass for all Statement objects
 * @author Morgan Douglas
 * @version 03/12/18
 */
public abstract class Statement extends Parseable
{

}
