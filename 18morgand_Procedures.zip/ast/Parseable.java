package ast;
/**
 * 
 * @author Morgan Douglas
 * @version Apr 13, 2018
 */
public abstract class Parseable
{

}
