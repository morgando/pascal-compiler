package ast;

import java.util.ArrayList;

import environment.Environment;

/**
 * Stores all Parseable objects associated with a Pascal program
 * 
 * @author Morgan Douglas
 * @version Apr 13, 2018
 */
public class Program extends Parseable
{
    Environment env;
    private Statement statement;
    
    /**
     * Constructor for Program objects
     * 
     * @param procedures
     * @param statements
     */
    public Program(Environment env, Statement statement)
    {
        this.env = env;
        this.statement = statement;
    }
    
    /**
     * @return the statement associated with the program
     */
    public Statement getStatement()
    {
        return statement;
    }
    
    /**
     * @return the environment associated with the program
     */
    public Environment getEnvironment()
    {
        return env;
    }

}
