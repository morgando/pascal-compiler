package evaluator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;



import ast.*;
import ast.Number;
import environment.*;
import parser.*;

/**
 * Responsible for handling all evaluations that arise during parsing
 * 
 * @author Morgan Douglas
 * @version Mar 19, 2018
 */
public class Evaluator 
{
    private int returnValue;
    
    /**
     * 
     * @param prog the program to be evaluated
     * @throws InvalidRelopException 
     */
    public int evalProgram(Program prog) throws InvalidRelopException
    {
        Environment env = prog.getEnvironment();
        Statement stmt = prog.getStatement();
        
        returnValue = 0;
        
        exec(stmt, env);
        
        return returnValue;
        
    }
    
    /**
     * Determines type of pascal statement, performing proper output
     * required by this type.
     * 
     * @param stmt the statement to be evaluated
     * @param env the environment in which the statement is being evaluated
     * @throws InvalidRelopException 
     */
    public void exec(Statement stmt, Environment env) throws InvalidRelopException
    {

        if(stmt.getClass().getName().equals("ast.Writeln"))
        {
            System.out.println(
                    eval(((Writeln) stmt).getExpression(), env));
        }
        else if(stmt.getClass().getName().equals("ast.Assignment"))
        {
            
            int val = eval(((Assignment)stmt).getExpression(), env);
            
            String var = ((Assignment)stmt).getVariable();
            
            env.setVariable(var, val);   
        }
        else if(stmt.getClass().getName().equals("ast.Block"))
        {
            ArrayList<Statement> stmts = ((Block)stmt).getStatements();
            Iterator<Statement> itr = stmts.iterator();

            while(itr.hasNext())
            {
                Statement nextState = itr.next();
                exec(nextState, env);
            }
        }
        else if(stmt.getClass().getName().equals("ast.If"))
        {
            Condition c = ((If) stmt).getCondition();
            Statement s = ((If) stmt).getStatement();
            Statement s2 = ((If) stmt).getElseStatement();
            Boolean b = evalCon(c, env);
            
            if(b)
                exec(s, env);
            else if(s2!=null)
                exec(s2, env);
        }
        else
        {
            Condition c = ((While) stmt).getCondition();
            Statement s = ((While) stmt).getStatement();

            while(evalCon(c, env))
                exec(s, env);
        }
                
    }
    
    /**
     * Determines type of Expression and evaluates int value accordingly
     * 
     * @param exp the Expression to be evaluated
     * @param env the Environment in which the Expression is being evaluated
     * @return int value of the Expression
     * @throws InvalidRelopException 
     */
    public int eval(Expression exp, Environment env) throws InvalidRelopException
    {
        int val;          //declares variable that will store return value
        
        if(exp.getClass().getName().equals("ast.BinOp"))    //evaluation if exp is of
        {                                                   //class BinOp
            String op = ((BinOp) exp).getOp();
            Expression exp1= ((BinOp) exp).getExp1();
            Expression exp2 = ((BinOp) exp).getExp2();
            int exp1Val = eval(exp1, env);
            int exp2Val = eval(exp2, env);
            
            if(op.equals("+"))
                val=exp1Val+exp2Val;
            else if(op.equals("-"))
                val=exp1Val-exp2Val;
            else if(op.equals("*"))
                val=exp1Val*exp2Val;
            else
                val=exp1Val/exp2Val;
        }
        else if(exp.getClass().getName().equals("ast.Number")) //evaluation if exp
        {                                                      //is of class Number
            val = ((Number) exp).getValue();
        }
        else if(exp.getClass().getName().equals("ast.ProcedureCall"))          //actions if statement is of type ProcedureCall
        {
            ArrayList<Expression> params = ((ProcedureCall) exp).getParams();
            
            ArrayList<Integer> paramVals = new ArrayList<Integer>();
            
            for(int i=0; i<params.size(); i++)                                  //evaluates & stores all passed parameters
            {
                paramVals.add(eval(params.get(i), env));
            }
            
            ProcedureDeclaration dec = env.getProcedure(((ProcedureCall) exp).getName());
            
            ArrayList<String> paramNames = dec.getParams();
            
            //ASK DATAR IF PARAMS SHOULD OVERRIDE OLD VARS
            
            Environment env2 = new Environment(env.getAllVars(), env.getAllProcedures()); //creates new procedure-specific env
                                                                                          //w/ all vars from superenvironment

            for(int i=0; i<paramNames.size(); i++)                          //puts params into procedure-specific env
            {
                env2.setVariable(paramNames.get(i), paramVals.get(i));
            }
            
            env2.setVariable(dec.getName(), 0);                             //adds return var to procedure env w/ default value
            

            
            exec(dec.getAction(), env2);                                    //executes statement associated with procedure
            
            val = env2.getVariable(dec.getName());   
        }
        else    //evaluation if exp is of class Variable
        {
            val = env.getVariable(((Variable) exp).getName());  
        }
        
        return val;
    }
    
    /**
     * Evaluates conditional expressions
     * 
     * @return boolean resulting from the execution of the relational evaluation
     * @throws InvalidRelopException 
     */
    public Boolean evalCon(Condition c, Environment env) throws InvalidRelopException
    {
        String relop = c.getRelop();
        
        Number exp1 = new Number(eval(c.getExp1(), env));
        Number exp2 = new Number(eval(c.getExp2(), env));
        
        if(relop.equals("="))
            return exp1==exp2;
        else if(relop.equals("<>"))
            return exp1!=exp2;
        else if(relop.equals("<"))
            return exp1.getValue()<exp2.getValue();
        else if(relop.equals(">"))
            return exp1.getValue()>exp2.getValue();
        else if(relop.equals("<="))
            return exp1.getValue()<=exp2.getValue();
        else if(relop.equals(">="))
            return exp1.getValue()>=exp2.getValue();
        else
            throw new InvalidRelopException(relop);
                
    }
    

}
